
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
short_version = '1.8.0'
version = '1.8.0'
full_version = '1.8.0'
git_revision = '67df668e175bfc12dac60d123c0887a42e0c82a2'
release = True

if not release:
    version = full_version
