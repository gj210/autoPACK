
# THIS FILE IS GENERATED FROM SCIPY SETUP.PY
short_version = '0.12.0'
version = '0.12.0'
full_version = '0.12.0'
git_revision = '3162880a80d5c4d2a5ca283c3c3c30a039f2bf44'
release = True

if not release:
    version = full_version
